//app.js
App({
  onLaunch: function () {
      let _this = this;
      setTimeout(function () { //防止第一次进入的是子页面，再回到首页时触发启动页
          _this.beginHide = true;
      }, 3000)
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  },
  globalData: {
    userInfo: null
  },

//   beginHide: false, //启动页是否已经关闭
    beginHide: true, //启动页是否已经关闭

//   测试用的日程数据
    scheduleData: [
        {
            id: "0",
            type: "0", //0私人 1工作 2其他
            content: "周日和朋友上海聚餐去公园一起玩耍的周日和朋友上海聚餐去公园一起玩耍的",
            dateDetail: "1", //是否展示具体时间 0否 1是
            beginDate:{
                year: 2019,
                month: 5,
                day: 14,
                hour: 14,
                minute: 21,
            },
            endDate: {
                year: 2019,
                month: 5,
                day: 31,
                hour: 15,
                minute: 32,
            },
            remindDate: 5,
            repeat: "0", //重复类型
            site: "上海市",
            other: "其他备注内容",
            finish: "0", //是否完成

            finishAni: 0, //完成动画
            scroll: "scrollLeft",
        }, {
            id: "1",
            type: "1", //0私人 1工作 2其他
            content: "工作列表",
            dateDetail: "0", //是否展示具体时间 0否 1是
            beginDate: {
                year: 2019,
                month: 5,
                day: 14,
                hour: 14,
                minute: 0,
            },
            endDate: {
                year: 2019,
                month: 5,
                day: 31,
                hour: 15,
                minute: 32,
            },
            remindDate: 0,
            repeat: "0", //重复类型
            site: "上海市",
            other: "其他备注内容",
            finish: "0", //是否完成

            finishAni: 0, //完成动画
            scroll: "scrollLeft",
        }, {
            id: "2",
            type: "2", //0私人 1工作 2其他
            content: "其他列表",
            dateDetail: "1", //是否展示具体时间 0否 1是
            beginDate: {
                year: 2019,
                month: 5,
                day: 14,
                hour: 2,
                minute: 0,
            },
            endDate: {
                year: 2019,
                month: 5,
                day: 31,
                hour: 6,
                minute: 11,
            },
            remindDate: 5,
            repeat: "0", //重复类型
            site: "上海市",
            other: "其他备注内容",
            finish: "1", //是否完成

            finishAni: 0, //完成动画
            scroll: "scrollLeft",
        },
    ],
    otherScheduleData: [
        {
            id: "0",
            type: "1", //0私人 1工作 2其他
            content: "他人推送的工作列表",
            dateDetail: "1", //是否展示具体时间 0否 1是
            beginDate: {
                year: 2019,
                month: 5,
                day: 14,
                hour: 14,
                minute: 0,
            },
            endDate: {
                year: 2019,
                month: 5,
                day: 31,
                hour: 15,
                minute: 32,
            },
            remindDate: 0,
            repeat: "0", //重复类型
            site: "上海市",
            other: "其他备注内容",
            finish: "0", //是否完成

            finishAni: 0, //完成动画
            scroll: "scrollLeft",
        }
    ]
})