// pages/list/list.js

Page({

    /**
     * 页面的初始数据
     */
    data: {
        mainchoose: "0", 
        mainData:[
            {
                id: "0",
                type: "0",
                content: "今日",
                num: 1
            },
            {
                id: "1",
                type: "1",
                content: "本周",
                num: 3
            },
            {
                id: "2",
                type: "2",
                content: "下周",
                num: 0
            },
            {
                id: "3",
                type: "3",
                content: "所有",
                num: 12
            },
            {
                id: "4",
                type: "4",
                content: "私人列表",
                num: 0
            },
            {
                id: "5",
                type: "5",
                content: "工作列表",
                num: 1
            }
        ]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },

    /**
     * 自定义事件
     */
    // 顶部tab切换
    mainChoose: function(e){
        console.log(e)
        this.setData({
            mainchoose: e.currentTarget.dataset.type
        })
    }
})