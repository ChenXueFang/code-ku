// pages/addschedule/addschedule.js
const app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        phoneType: "android", //用户机型
        inputShow: true, //是否可以展示输入框

        content: null, //行程内容
        choosedateShow: false, //是否展示选择时间弹窗
        dateType: "begin", //0当前操作的是开始日期，1当前操作的是结束日期
        beginDate: "尚未设置", //默认的开始日期
        beginDateNo: "尚未设置", //任意时间时
        endDate: "尚未设置", //默认的结束日期
        endDateNo: "尚未设置",
        dateDetail: "1",  //是否设置具体时间
        // 提醒
        remindDatas: ["不提醒", "准时提醒", "提前五分钟", "提前30分钟", "提前1小时","提前一天"], //提醒弹窗的数据
        remindShow: false,
        remindChoose: 0, //当前默认预选中提醒项
        remindChoosed: 0, //确定选中的提醒项
        // 选择日程
        scheduleShow: false,
        scheduleDatas: ["私人列表", "工作列表", "日常"], 
        scheduleChoose: 1, 
        scheduleChoosed: null, 
        // 重复
        repeatShow: false,
        repeatDatas: ["无", "每天","每周", "工作日（周一至周五）","每月","每年"],
        repeatChoose: 0,
        repeatChoosed: 0, 

        // 推送
        sendShow: false,
        sendDatas: ["手机用户1890", "手机用户1572"],
        sendChoose: null,
        sendChoosed: null, 
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        let _this = this;
        // 获取用户机型
        let phone = wx.getSystemInfoSync();  //调用方法获取机型   
        if (phone.platform == 'ios') {
            _this.setData({
                phoneType: "ios",
            })
        }
        else if (phone.platform == 'android') {
            _this.setData({
                phoneType: "android",
            })
        }

        console.log(options);
        if (options.id){
            for (let i = 0; i < app.scheduleData.length; i++){
                if (app.scheduleData[i].id == options.id){
                    console.log(app.scheduleData[i])
                    this.setData({
                        scheduleChoosed: app.scheduleData[i].type,
                        content: app.scheduleData[i].content,
                        dateDetail: app.scheduleData[i].dateDetail,
                        beginDate: app.scheduleData[i].beginDate.month + "-" + app.scheduleData[i].beginDate.day + " " + app.scheduleData[i].beginDate.hour + ":" + app.scheduleData[i].beginDate.minute,
                        beginDateNo: app.scheduleData[i].beginDate.month + "-" + app.scheduleData[i].beginDate.day,
                        endDate: app.scheduleData[i].endDate.month + "-" + app.scheduleData[i].endDate.day + " " + app.scheduleData[i].endDate.hour + ":" + app.scheduleData[i].endDate.minute,
                        endDateNo: app.scheduleData[i].endDate.month + "-" + app.scheduleData[i].endDate.day,
                        repeatChoose: parseInt(app.scheduleData[i].repeat),
                        repeatChoosed: parseInt(app.scheduleData[i].repeat),
                    })
                }
            }
        }
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },

    /**
     * 自定义事件
     */
    no: function(){},
    // 任意时间开关
    switchChange: function(e){
        console.log(e.detail.value)
        if (e.detail.value){
            this.setData({
                dateDetail: "0"
            })
        }else{
            this.setData({
                dateDetail: "1"
            })
        }
        this.setData({
            dateDetail: !e.detail.value
        })
    },

    /**
     * 弹窗事件begin
     */
    // 打开提醒弹窗
    openRemind: function () {
        this.setData({
            remindShow: true,
            inputShow: false,
        })
    },
    // 关闭提醒弹窗
    closeRemind: function(){
        this.setData({
            remindShow: false,
            inputShow: true,
        })
    },
    // 选择提醒时间
    chooseRemind: function(e){
        console.log(e)
        this.setData({
            remindChoose: e.currentTarget.dataset.index
        })
    },
    //确定选中的提醒项
    remindChoosed: function(){
        this.setData({
            remindChoosed: this.data.remindChoose
        })
        this.closeRemind();
    },
    // 打开日程弹窗
    openSchedule: function () {
        this.setData({
            scheduleShow: true,
            inputShow: false,
        })
    },
    // 关闭日程弹窗
    closeSchedule: function () {
        this.setData({
            scheduleShow: false,
            inputShow: true,
        })
    },
    // 选择日程列表
    chooseSchedule: function (e) {
        console.log(e)
        this.setData({
            scheduleChoose: e.currentTarget.dataset.index
        })
    },
    //确定选中的日程
    scheduleChoosed: function () {
        this.setData({
            scheduleChoosed: this.data.scheduleChoose
        })
        this.closeSchedule();
    },
    // 打开重复弹窗
    openrepeat: function () {
        this.setData({
            repeatShow: true,
            inputShow: false,
        })
    },
    // 关闭重复弹窗
    closerepeat: function () {
        this.setData({
            repeatShow: false,
            inputShow: true,
        })
    },
    // 选择重复列表
    chooserepeat: function (e) {
        console.log(e)
        this.setData({
            repeatChoose: e.currentTarget.dataset.index
        })
    },
    //确定重复的日程
    repeatChoosed: function () {
        this.setData({
            repeatChoosed: this.data.repeatChoose
        })
        this.closerepeat();
    },
    // 打开推送弹窗
    opensend: function () {
        this.setData({
            sendShow: true,
            inputShow: false,
        })
    },
    // 关闭推送弹窗
    closesend: function () {
        this.setData({
            sendShow: false,
            inputShow: true,
        })
    },
    // 选择推送列表
    choosesend: function (e) {
        console.log(e)
        this.setData({
            sendChoose: e.currentTarget.dataset.index
        })
    },
    //确定推送的日程
    sendChoosed: function () {
        this.setData({
            sendChoosed: this.data.sendChoose
        })
        this.closesend();
    },
    /**
     * 弹窗事件end
     */
    // 展示时间选择组件
    showChoosedate: function (e) {
        this.setData({
            choosedateShow: true,
            inputShow: false,
            dateType: e.currentTarget.dataset.type
        })
    },
    // 关闭时间选择组件
    closeChoosedate: function () {
        this.setData({
            choosedateShow: false,
            inputShow: true,
        })
    },
    // 选中的时间
    returnChoosedate: function (e) {
        console.log(e)
        if (e.detail.month<10){
            e.detail.month = "0" + e.detail.month
        }
        if (e.detail.day < 10) {
            e.detail.day = "0" + e.detail.day
        }
        if (e.detail.hour < 10) {
            e.detail.hour = "0" + e.detail.hour
        }
        if (e.detail.minute < 10) {
            e.detail.minute = "0" + e.detail.minute
        }

        let date = e.detail.month + "-" + e.detail.day + " " + e.detail.hour + ":" + e.detail.minute;
        let dateNo = e.detail.month + "-" + e.detail.day; 

        if (this.data.dateType == "begin"){
            this.setData({
                beginDate: date,
                beginDateNo: dateNo
            })
        } else if (this.data.dateType == "end"){
            this.setData({
                endDate: date,
                endDateNo: dateNo
            })
        }
    },
    // 提交数据
    putData: function(){
        let _this = this;
        if (getCurrentPages().length > 1) {
            wx.navigateBack({
                delta: 1,
            })
        } else {
            wx.reLaunch({
                url: '../calendar/calendar',
            })
        }
    }

})