// pages/myself/myself.js

const app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        balls: [1, 2, 3, 4, 5, 5, 6, 7]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {
        let obj = {
            "type": "touchstart",
            "timeStamp": 3115,
            "target": {
                "id": "",
                "offsetLeft": 100,
                "offsetTop": 100,
                "dataset": {}
            },
            "currentTarget": {
                "id": "",
                "offsetLeft": 100,
                "offsetTop": 100,
                "dataset": {}
            },
            "touches": [{
                "identifier": 0,
                "pageX": 151,
                "pageY": 151,
                "clientX": 151,
                "clientY": 151,
                "force": 1
            }],
            "changedTouches": [{
                "identifier": 0,
                "pageX": 151,
                "pageY": 151,
                "clientX": 151,
                "clientY": 151,
                "force": 1
            }],
            "instance": {
                "selectAllComponents": null,
                "selectComponent": null,
                "removeClass": null,
                "addClass": null,
                "hasClass": null,
                "setStyle": null,
                "getDataset": null,
                "getState": null,
                "triggerEvent": null,
                "callMethod": null,
                "requestAnimationFrame": null
            }
        }
        let obj2 = {
            "selectAllComponents": null,
            "selectComponent": null,
            "removeClass": null,
            "addClass": null,
            "hasClass": null,
            "setStyle": null,
            "getDataset": null,
            "getState": null,
            "triggerEvent": null,
            "callMethod": null,
            "requestAnimationFrame": null
        };
        let obj3 = {
            "type": "touchend",
            "timeStamp": 3714,
            "target": {
                "id": "",
                "offsetLeft": 63,
                "offsetTop": 34,
                "dataset": {}
            },
            "currentTarget": {
                "id": "",
                "offsetLeft": 15,
                "offsetTop": 413,
                "dataset": {
                    "direction": "scrollLeft",
                    "id": "1"
                }
            },
            "touches": [],
            "changedTouches": [{
                "identifier": 0,
                "pageX": 203,
                "pageY": 466,
                "clientX": 203,
                "clientY": 466,
                "force": 0
            }],
            "instance": {
                "selectAllComponents": null,
                "selectComponent": null,
                "removeClass": null,
                "addClass": null,
                "hasClass": null,
                "setStyle": null,
                "getDataset": null,
                "getState": null,
                "triggerEvent": null,
                "callMethod": null,
                "requestAnimationFrame": null
            }
        }
    }
})