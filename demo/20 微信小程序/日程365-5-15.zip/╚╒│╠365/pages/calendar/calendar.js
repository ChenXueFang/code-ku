// pages/test/test.js
const app = getApp();

let moveStart = 0; //日历左右滑动开始
let moveEnd = 0; //日历左右滑动结束
let pagemoves = 0; //页面上下滑动开始
let pagemovee = 0; //页面上下滑动结束
let date = new Date();
let month = date.getMonth()+1;
Page({

    /**
     * 页面的初始数据
     */
    data: {
        reset: true,
        scrollId: "calendarBox",
        pageScale: 1, // 页面缩放比例
        pageHeight: 0, //屏幕高度
        beginHide: true, //启动页是否已经关闭
        beginAmt: true, //启动页动画 748rpx

        scroll: false, //是否允许滚动
        dataScroll: false, //数据长度的内容是否足以滚动
        calendarShow: true, //当前日历是否处于展开状态
        chooseDayNum: 0, //所选中的日期在当前日历的第几行
        calenderBoxAnm: {}, //日历外层盒子的动画
        calendarAnm: {}, //日历内部根据选中日期所在行数进行相应的动画

        //获取当前年月日
        year: date.getFullYear(), 
        month: month,
        day: date.getDate(),

        todayScheduleData:{ //今日日程的相关状态（包含今日的他人推送）
            show: false,
            num: 0,
            finished: 0,
        },
        todayScheduleDatas:[ //今日日程的详细数据数据
        ],
        otherScheduleDataShow: false, //是否展示他人推送
        otherScheduleDatas: [], //他人推送的详细数据
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        let _this = this;
        this.setData({
            pageScale: wx.getSystemInfoSync().windowWidth / 375 ,
            pageHeight: wx.getSystemInfoSync().windowHeight
        })
        console.log(wx.getSystemInfoSync().windowHeight)
        
        this.findTodaySchedule({
            year: date.getFullYear(),
            month: date.getMonth()+1,
            day: date.getDate(),
        });
        // 启动页是否已经关闭
        if (!app.beginHide) {
            // 如启动页未关闭，则把首页的启动页开关置为未关闭状态，比隐藏底部导航栏
            wx.hideTabBar()
            _this.setData({ 
                beginHide: false ,
                beginAmt: false
            }) 

            setTimeout(function () { // 如果已经获取到了数据，则两秒后关闭启动页
                _this.setData({
                    beginAmt: true
                });
                app.beginHide = true;
                setTimeout(function(){
                    wx.showTabBar()
                    _this.setData({
                        beginHide: true,
                    });
                },800)
            }, 2000)
        } else { 
            _this.setData({ 
                beginHide: true ,
                beginAmt: true
            }) 
        }
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    // onPullDownRefresh: function () {

    // },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 页面滚动处理函数
     */
    // onPageScroll: function(e){
    //     console.log(e)
    // },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },

    /**
     * 自定义事件
     */
    // 跳转到添加日程
    toaddschedule: function(){
        wx.navigateTo({
            url: '../addschedule/addschedule',
        })
    },
    // 跳转到日程详情
    toscheduledetail: function (e) {
        console.log(e);
        wx.navigateTo({
            url: '../addschedule/addschedule?id='+e.currentTarget.dataset.id,
        })
    },
    //切换日程完成状态
    changeFinish: function(e){
        this.setData({reset: true})
        let _this = this;
        let arrys = this.data.todayScheduleDatas;
        let arrysObj = "todayScheduleDatas";
        console.log(e)
        if (e.currentTarget.dataset.type == "other"){
            arrys = this.data.otherScheduleDatas;
            arrysObj = "otherScheduleDatas"
        }
        arrys[e.currentTarget.dataset.index].scroll = "scrollLeft";
        if (arrys[e.currentTarget.dataset.index].finish=="0"){
            arrys[e.currentTarget.dataset.index].finish = "1";
            arrys[e.currentTarget.dataset.index].finishAni = 1;
            this.data.todayScheduleData.finished += 1;
            this.setData({
                [arrysObj]: arrys,
                todayScheduleData: this.data.todayScheduleData,
                todayScheduleDatas: arrys
            })

            for (let i = 0; i < arrys.length;i++){
                arrys[i].finishAni = 0;
            }
            let arr = arrys[e.currentTarget.dataset.index];
            arrys.splice(e.currentTarget.dataset.index,1);
            arrys.push(arr);
            setTimeout(function() {
                _this.setData({
                    [arrysObj]: arrys
                })
            },1400)

            // app data
            let arrx = app.scheduleData;
            if (e.currentTarget.dataset.type == "other") {
                arrx = app.otherScheduleData;
            }
            for (let i = 0; i < arrx.length; i++) {
                if (arrx[i].id == e.currentTarget.dataset.id) {
                    arrx[i].finish = "1";

                    let arr = arrx[i];
                    arrx.splice(i, 1);
                    arrx.push(arr);
                    break;
                }
            }
            if (e.currentTarget.dataset.type == "other") {
                app.otherScheduleData = arrx;
            } else {
                app.scheduleData = arrx;
            }
        }else{
            arrys[e.currentTarget.dataset.index].finish = "0";
            arrys[e.currentTarget.dataset.index].finishAni = 0;
            this.data.todayScheduleData.finished -= 1;

            let arr = arrys[e.currentTarget.dataset.index];
            arrys.splice(e.currentTarget.dataset.index, 1);
            arrys.unshift(arr);
            this.setData({
                [arrysObj]: arrys,
                todayScheduleData: this.data.todayScheduleData,
                todayScheduleDatas: arrys
            })

            // app data
            let arrx = app.scheduleData;
            if (e.currentTarget.dataset.type == "other") {
                arrx = app.otherScheduleData;
            }
            for (let i = 0; i < arrx.length; i++) {
                if (arrx[i].id == e.currentTarget.dataset.id) {
                    arrx[i].finish = "0";

                    let arr = arrx[i];
                    arrx.splice(i, 1);
                    arrx.unshift(arr);
                    break;
                }
            }
            if (e.currentTarget.dataset.type == "other") {
                app.otherScheduleData = arrx;
            } else {
                app.scheduleData = arrx;
            }
        }
    },
    // 删除日程
    removeschedule: function(e){
        this.setData({ reset: true })
        let _this = this;
        let arrys = this.data.todayScheduleDatas;
        let arrysObj = "todayScheduleDatas";
        console.log(e)
        if (e.currentTarget.dataset.type == "other") {
            arrys = this.data.otherScheduleDatas;
            arrysObj = "otherScheduleDatas";
        }
        this.data.todayScheduleData.num -= 1;

        if (arrys[e.currentTarget.dataset.index].finish == "1"){
            this.data.todayScheduleData.finished -= 1;
        }
        arrys.splice(e.currentTarget.dataset.index, 1);

        _this.setData({
            [arrysObj]: arrys,
            todayScheduleData: _this.data.todayScheduleData,
        })

        if (_this.data.otherScheduleDatas.length < 1) {
            this.data.otherScheduleDataShow = false
        }
        if (this.data.todayScheduleDatas.length < 1 && _this.data.otherScheduleDatas.length < 1) {
            this.data.todayScheduleData.show = false
        }
        _this.setData({
            otherScheduleDataShow: this.data.otherScheduleDataShow,
            todayScheduleData: this.data.todayScheduleData,
        })
        
        let arrx = app.scheduleData;
        if (e.currentTarget.dataset.type == "other") {
            arrx = app.otherScheduleData;
        }
        for (let i = 0; i < arrx.length; i++){
            if (arrx[i].id == e.currentTarget.dataset.id){
                arrx.splice(i,1);
                break;
            }
            console.log(arrx)
        }
        if (e.currentTarget.dataset.type == "other") {
            app.otherScheduleData = arrx;
        }else{
            app.scheduleData = arrx;
        }
    },
    // 单个日程滑动开始
    // scrollMoveStart: function(e){
    //     console.log(e)
    //     moveStart = e.changedTouches[0].pageX
    // },
    // scrollMoveEnd: function (e) {
    //     console.log(e)
    //     let _this = this;
    //     let arrys = this.data.todayScheduleDatas;
    //     let arrysObj = "todayScheduleDatas";
    //     if (e.currentTarget.dataset.type == "other") {
    //         arrys = this.data.otherScheduleDatas;
    //         arrysObj = "otherScheduleDatas";
    //     }

    //     moveEnd = e.changedTouches[0].pageX
    //     if (moveEnd - moveStart < -60){
    //         arrys[e.currentTarget.dataset.index].scroll = "scrollRight"; 
    //     }else{
    //         arrys[e.currentTarget.dataset.index].scroll = arrys[e.currentTarget.dataset.index].scroll;
    //     } 
    //     if (moveEnd - moveStart > 60){
    //         arrys[e.currentTarget.dataset.index].scroll = "scrollLeft";
    //     } else {
    //         arrys[e.currentTarget.dataset.index].scroll = arrys[e.currentTarget.dataset.index].scroll;
    //     } 
    //     this.setData({
    //         [arrysObj]: arrys
    //     })
    // },
    // 今日日程查询
    findTodaySchedule: function(e){
        let date = new Date();
        if(e.year){
            date = new Date(this.data.year, this.data.month - 1, this.data.day);   
        }else{
            date = new Date(e.detail.year, e.detail.month - 1, e.detail.day);
        }
        this.calcChooseNum(date)
        this.pageMoveEnd({changeDay: true})
        let arrsToday = []; //今日日程的数据
        let arrsOther = [];  //他人推送的数据

        let arrsNum = 0; //今日的日程总数
        let arrsFinish = 0; //已完成的日程数
        let arrsOtherNum = 0; //他人推送的日程数
        // 今日日程
        for (let i = 0; i < app.scheduleData.length; i++) {
            let dateB = new Date(app.scheduleData[i].beginDate.year, app.scheduleData[i].beginDate.month - 1, app.scheduleData[i].beginDate.day);
            let dateE = new Date(app.scheduleData[i].endDate.year, app.scheduleData[i].endDate.month - 1, app.scheduleData[i].endDate.day);
            if (date.getTime() - dateB.getTime() >= 0 && date.getTime() - dateE.getTime() <= 0) {
                app.scheduleData[i] = this.dateSet(app.scheduleData[i])
                arrsToday.push(app.scheduleData[i]);

                arrsNum++;
                if (app.scheduleData[i].finish == "1"){
                    arrsFinish++;
                }
            }
        }
        // 他人推送
        for (let i = 0; i < app.otherScheduleData.length; i++) {
            let dateB = new Date(app.otherScheduleData[i].beginDate.year, app.otherScheduleData[i].beginDate.month - 1, app.otherScheduleData[i].beginDate.day);
            let dateE = new Date(app.otherScheduleData[i].endDate.year, app.otherScheduleData[i].endDate.month - 1, app.otherScheduleData[i].endDate.day);
            if (date.getTime() - dateB.getTime() >= 0 && date.getTime() - dateE.getTime() <= 0) {
                app.otherScheduleData[i] = this.dateSet(app.otherScheduleData[i])
                arrsOther.push(app.otherScheduleData[i]);

                arrsNum++;
                arrsOtherNum++;
                if (app.otherScheduleData[i].finish == "1") {
                    arrsFinish++;
                }
            }
        }
        if (arrsNum > 0){
            this.data.todayScheduleData.show = true;
        }else{
            this.data.todayScheduleData.show = false;
        }
        if (arrsOtherNum > 0){
            this.data.otherScheduleDataShow = true;
        }else{
            this.data.otherScheduleDataShow = false;
        }
        this.data.todayScheduleData.num = arrsNum;
        this.data.todayScheduleData.finished = arrsFinish;
        this.setData({
            todayScheduleDatas: arrsToday,
            otherScheduleDatas: arrsOther,
            todayScheduleData: this.data.todayScheduleData,
            otherScheduleDataShow: this.data.otherScheduleDataShow
        })
        // 364(356) -> 120  此处暂时以日历收缩后的高度（120）来计算。
        console.log(120 * this.data.pageScale + 30 + 24 + 67 * (arrsToday.length + arrsOther.length))
        if (120 * this.data.pageScale + 30 + 24 + 67 * (arrsToday.length + arrsOther.length)>this.data.pageHeight){
            this.setData({
                dataScroll: true
            })
        }else{
            this.setData({
                dataScroll: false
            })
        }
    },
    // 时间处理
    dateSet: function (obj){
        if (obj.beginDate.month > 9) {
            obj.showDate = obj.beginDate.month;
        } else {
            obj.showDate = "0" + obj.beginDate.month;
        }
        if (obj.beginDate.day > 9) {
            obj.showDate += "/" + obj.beginDate.day;
        } else {
            obj.showDate += "/0" + obj.beginDate.day;
        }
        // 是否加上具体时间
        if (obj.dateDetail == "1") {
            if (obj.beginDate.hour > 9) {
                obj.showDate += " " + obj.beginDate.hour;
            } else {
                obj.showDate += " 0" + obj.beginDate.hour;
            }
            if (obj.beginDate.minute > 9) {
                obj.showDate += ":" + obj.beginDate.minute;
            } else {
                obj.showDate += ":0" + obj.beginDate.minute;
            }
        }
        // 结束时间
        if (obj.endDate.month > 9) {
            obj.showDate += "-" + obj.endDate.month;
        } else {
            obj.showDate += "-0" + obj.endDate.month;
        }
        if (obj.endDate.day > 9) {
            obj.showDate += "/" + obj.endDate.day;
        } else {
            obj.showDate += "/0" + obj.endDate.day;
        }
        // 是否加上具体时间
        if (obj.dateDetail == "1") {
            if (obj.endDate.hour > 9) {
                obj.showDate += " " + obj.endDate.hour;
            } else {
                obj.showDate += " 0" + obj.endDate.hour;
            }
            if (obj.endDate.minute > 9) {
                obj.showDate += ":" + obj.endDate.minute;
            } else {
                obj.showDate += ":0" + obj.endDate.minute;
            }
        }
        return obj
    },
    // 计算选中的日期属于第几行
    calcChooseNum: function (date){
        let dateN = new Date(date.getFullYear(),date.getMonth(),1)
        this.setData({
            chooseDayNum: Math.ceil((date.getDate() + dateN.getDay()) / 7)
        })

        console.log(this.data.chooseDayNum)
    },

    // 页面滑动开始
    pageMoveStart: function(e){
        pagemoves = e.touches[0].clientY
    },
    // 页面滑动结束
    pageMoveEnd: function (e) {
        let direction = null;
        // e.changeDay 有值时是在js调用的pageMoveEnd方法。没值时是页面滑动触发的方法
        if (e.changeDay){ 
            if (this.data.calendarShow){ //判断当前日历是否处于展开状态
                direction = "up"
            }else{
                direction = "down"
            }
        }else{
            pagemovee = e.changedTouches[0].clientY;
            if (pagemovee - pagemoves > 100) {
                direction = "up"
            } else if (pagemovee - pagemoves < -80) {
                direction = "down"
            }
        }

        let animation = wx.createAnimation({
            duration: 400,
            timingFunction: 'ease',
        })
        this.animation = animation
       
        if (direction == "up" ){ //向下滑动
            this.animation.height(356 * this.data.pageScale).step();
            this.setData({
                calenderBoxAnm: this.animation.export()
            })
            this.animation.top(0).step();
            this.setData({
                calendarAnm: this.animation.export(),
                scroll: false,
                scrollId: "calendarBox",
            })
            this.data.calendarShow = true;
        } else if (direction == "down"){ //向上滑动
            this.animation.height(120 * this.data.pageScale).step();
            this.setData({
                calenderBoxAnm: this.animation.export()
            })
            this.animation.top(-45.70 * (this.data.chooseDayNum - 1) * this.data.pageScale).step();
            this.setData({
                calendarAnm: this.animation.export(),
                scroll: true
            })
            this.data.calendarShow = false;
        }
    },
    // 日程滑动反馈
    scheduleScrollBack: function(e){
        console.log(e)
        let _this = this;
        let arrys = this.data.todayScheduleDatas;
        let arrysObj = "todayScheduleDatas";
        if (e.type == "other") {
            arrys = this.data.otherScheduleDatas;
            arrysObj = "otherScheduleDatas";
        }
        if (e.direction == 'scrollLeft'){
            arrys[e.index].scroll = "scrollRight";
        }else{
            arrys[e.index].scroll = "scrollLeft";
        }
        
        this.setData({
            [arrysObj]: arrys
        })
    }

})