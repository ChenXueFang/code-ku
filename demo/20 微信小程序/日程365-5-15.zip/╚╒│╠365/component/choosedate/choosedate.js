// component/choosedate/choosedate.js
const date = new Date()
const years = []
const months = []
const days = []
const hours = []
const minutes = []

for (let i = 1990; i <= 2090; i++) {
    years.push(i)
}

for (let i = 1; i <= 12; i++) {
    months.push(i)
}

for (let i = 1; i <= 31; i++) {
    days.push(i)
}
for (let i = 0; i <= 23; i++) {
    hours.push(i)
}
for (let i = 0; i <= 59; i++) {
    minutes.push(i)
}
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        dateDetail: {
            value: true,
            type: Boolean
        }
    },

    /**
     * 组件的初始数据
     */
    data: {
        years: years,
        year: 11,
        months: months,
        month: null,
        days: days,
        day: null,
        hours: hours,
        hour: null,
        minutes: minutes,
        minute: null,
        value: [0, 0, 0, 0],
    },

    /**
     * 组件创建
     */
    attached(){
        this.setData({
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate(),
            hour: date.getHours(),
            minute: date.getMinutes(),
            value: [date.getMonth(), date.getDate() - 1, date.getHours(), date.getMinutes()]
        })
    },

    /**
     * 组件的方法列表
     */
    methods: {
        // 滚动日期时
        bindChange(e) {
            const val = e.detail.value
            let dateN = new Date(date.getFullYear(), val[0] + 1, 0);
            let daysN = [];
            for (let i = 1; i <= dateN.getDate(); i++) {
                daysN.push(i)
            }
            this.setData({
                month: val[0] + 1,
                days: daysN,
                day: val[1] + 1,
                hour: val[2],
                minute: val[3]
            })
        },
        // 点击确定时
        chooseDate() {
            let obj = {
                year: this.data.year,
                month: this.data.month,
                day: this.data.day,
                hour: this.data.hour,
                minute: this.data.minute,
            }
            this.triggerEvent("returnChoosedate", obj)
            this.triggerEvent("closeChoosedate");
        },
        
        closeChoosedate(){
            this.triggerEvent("closeChoosedate")
        }
    }
})
