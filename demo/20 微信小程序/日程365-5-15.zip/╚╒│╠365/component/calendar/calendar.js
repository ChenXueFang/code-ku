// component/calendar.js
const app = getApp();
var ccFile = require('../../utils/calendar-converter.js')
var calendarConverter = new ccFile.CalendarConverter(); 

//月份天数表
var DAY_OF_MONTH = [
    [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
    [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
];

//判断当前年是否闰年
var isLeapYear = function (year) {
    if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
        return 1
    else
        return 0
};

//获取当月有多少天
var getDayCount = function (year, month) {
    return DAY_OF_MONTH[isLeapYear(year)][month];
};

//获取当前索引下是几号
// var getDay = function (index) {
//     return index - curDayOffset;
// };

var pageData = {
    date: ["", "", ""],                //当前日期字符串（抛弃不用）
    dateNow: "",  //当前日期字符串

    //arr数据是与索引对应的数据信息
    arrIsShow: [[], [], []],          //是否显示此日期
    arrDays: [[], [], []],            //关于几号的信息
    arrInfoEx: [[], [], []],          //农历节假日等扩展信息
    arrInfoExShow: [[], [], []],      //处理后用于显示的扩展信息

    //选择一天时显示的信息
    detailData: {
        curDay: "",         //detail中显示的日信息
        curInfo1: "",
        curInfo2: "",
    },

    //////////////////////////////////////////
    showDatas: [{ year: 2018, month: 12 }, { year: 2018, month: 1 }, { year: 2018, month: 2 }],
    showYear: 2019, //当前展示的年
    showMonth: 1, //当前展示的月
    nowIndex: 1,  //当前索引
    indexCalc: 1, //用于计算月份
    chooseOtherDay: 1, //点击当月中的非当月日期时，记录点击的号数
    NowYear: null, //今日的实际日期
    NowMonth: null,
    NowDay: null, 
}

//设置当前详细信息的索引，前台的详细信息会被更新
var setCurDetailIndex = function (index, showIndex) {

    var curEx = pageData.arrInfoEx[showIndex][index];
    // curDay = curEx.sDay - 1;
    pageData.detailData.curDay = curEx.sDay;
    pageData.detailData.curInfo1 = "农历" + curEx.lunarMonth + "月" + curEx.lunarDay;
    pageData.detailData.curInfo2 = curEx.cYear + curEx.lunarYear + "年 " + curEx.cMonth + "月 " + curEx.cDay + "日 " + curEx.lunarFestival;
}

//刷新全部数据(传过来的month,day的值均-1再传过来) showIndex要刷新的哪一块数据的索引
var refreshPageData = function (year, month, day, showIndex) {
    if (month == 12) {
        month = 0;
    }
    if (month + 1 > 9){
        pageData.date[showIndex] = year + '-' + (month + 1);
    }else{
        pageData.date[showIndex] = year + '-0' + (month + 1);
    }
    if(day > 9){
        pageData.date[showIndex] += '-' + (day + 1);
    }else{
        pageData.date[showIndex] += '-0' + (day + 1);
    }

    var offset = new Date(year, month, 1).getDay();

    let num = 1;
    for (var i = 0; i < 42; ++i) {
        pageData.arrIsShow[showIndex][i] = i < offset || i >= getDayCount(year, month) + offset ? false : true;
        if (i >= getDayCount(year, month) + offset){
            let monthx = month + 1;
            if (monthx > 11) {
                monthx = 0;
            }
            let obj = {}
            obj.date = i - getDayCount(year, month) - offset + 1;
            obj.month = monthx;
            pageData.arrDays[showIndex][i] = obj;
        } else if (i < offset){
            let monthx = month - 1;
            let yearx = year;
            if (monthx < 0){
                monthx = 11;
                yearx -= 1;
            }
            let obj = {}
            obj.date = getDayCount(yearx, monthx) - offset + num;
            obj.month = monthx;
            pageData.arrDays[showIndex][i] = obj;
            num++;
        }else{
            let obj = {}
            obj.date = i - offset + 1;
            obj.month = month;
            pageData.arrDays[showIndex][i] = obj;
        }
        
        var d = new Date(year, month, i - offset + 1);
        var dEx = calendarConverter.solar2lunar(d);
        pageData.arrInfoEx[showIndex][i] = dEx;
        if ("" != dEx.lunarFestival) {
            pageData.arrInfoExShow[showIndex][i] = dEx.lunarFestival;
        }
        else if ("初一" === dEx.lunarDay) {
            pageData.arrInfoExShow[showIndex][i] = dEx.lunarMonth + "月";
        }
        else {
            pageData.arrInfoExShow[showIndex][i] = dEx.lunarDay;
        }
    }

    // setCurDetailIndex(offset + day, showIndex); //更改
};

var curDate = new Date();
var curMonth = curDate.getMonth();
var curYear = curDate.getFullYear();
var curDay = curDate.getDate();
// curDay = 29
// const NowDay = 29
const NowYear = curDate.getFullYear();
const NowMonth = curDate.getMonth();
const NowDay = curDate.getDate();
pageData.NowYear = NowYear;
pageData.NowMonth = NowMonth;
pageData.NowDay = NowDay;
refreshPageData(curYear, curMonth - 1, 0, 0);
refreshPageData(curYear, curMonth, curDay - 1, 1);
refreshPageData(curYear, curMonth + 1, 0, 2);
if (curMonth - 1 < 1) {
    pageData.showDatas = [{ year: curYear - 1, month: 12 }, { year: curYear, month: 1 }, { year: curYear, month: 2 }];
} else if (curMonth + 1 > 12) {
    pageData.showDatas = [{ year: curYear, month: 11 }, { year: curYear, month: 12 }, { year: curYear + 1, month: 1 }];
} else {
    pageData.showDatas = [{ year: curYear, month: curMonth - 1 }, { year: curYear, month: curMonth }, { year: curYear, month: curMonth + 1 }];
}
pageData.showMonth = curMonth; //当前展示的月
// pageData.showYear = curYear; //当前展示的月

// 当前月1号所在的是星期几
let firstDayWeek = new Date(curYear, curMonth, 1).getDay()
setCurDetailIndex(firstDayWeek + curDay - 1, 1);
// setCurDetailIndex(curDay,1)

let swiperChange = true; //是否可以触发轮播图滑动（防止日期跳转时和滑动方法冲突）
Component({
    /**
     * 组件的属性列表
     */
    properties: {

    },

    /**
     * 组件的初始数据
     */
    data: pageData,
    // 组件创建
    attached: function(){
        this.setData({
            showYear: curYear
        })
        this.findMonthSchedule();
    },
    // 数据监听
    observers: {
        'showYear, showMonth, detailData': function (showYear, showMonth, detailData){
            this.triggerEvent("dateReturn", {
                year: showYear,
                month: showMonth+1,
                day: detailData.curDay,
            })
            // 时间暂时到页面
            if (showMonth + 1 > 9) {
                pageData.dateNow = showYear + '-' + (showMonth + 1);
            } else {
                pageData.dateNow = showYear + '-0' + (showMonth + 1);
            }
            if (detailData.curDay > 9) {
                pageData.dateNow += '-' + detailData.curDay;
            } else {
                pageData.dateNow += '-0' + detailData.curDay;
            }
            this.setData({
                dateNow: pageData.dateNow
            })
        },
        "showMonth": function(){
            this.findMonthSchedule();
        }
    },

    /**
     * 组件的方法列表
     */
    methods: {
        // 点击滑动时
        swiperchange: function (e) {
            if (!swiperChange) {
                swiperChange = true;
                return;
            }
            // console.log(e)
            let currentIndex = e.detail.current;
            let _this = this;
            let x = currentIndex - pageData.indexCalc;
            if (x == 1 || x == -2) { //如果是往前滑动则月份+
                pageData.showMonth += 1;  //当前月份+1
                if (pageData.showMonth > 11) { //判断当前月份边界
                    pageData.showMonth = 0;
                    pageData.showYear += 1; //当前展示的月
                }
                let num = currentIndex + 1; //索引指到预加载的下一位
                if (num > 2) {
                    num = 0
                }
                //预加载的下一位的年份等于当前年份
                if (num - 1 < 0) {
                    pageData.showDatas[num].year = pageData.showDatas[2].year
                } else {
                    pageData.showDatas[num].year = pageData.showDatas[num - 1].year;
                }
                if (pageData.showMonth + 1 > 11) { //判断预加载月份的边界，如果超出边界，年份+1
                    pageData.showDatas[num].year = pageData.showDatas[num].year + 1
                    pageData.showDatas[num].month = 0
                } else {
                    pageData.showDatas[num].month = pageData.showMonth + 1;
                }
                pageData.nowIndex = currentIndex;
                pageData.indexCalc = currentIndex;
                _this.goNextMonth(num);
            } else { //如果是往后滑动则月份-
                pageData.showMonth -= 1;
                let num = currentIndex - 1;

                if (pageData.showMonth < 0) {
                    pageData.showMonth = 11
                    pageData.showYear -= 1; //当前展示的月
                }
                if (num < 0) {
                    num = 2
                }
                if (num + 1 > 2) {
                    pageData.showDatas[num].year = pageData.showDatas[0].year
                } else {
                    pageData.showDatas[num].year = pageData.showDatas[num + 1].year;
                }
                if (pageData.showMonth - 1 < 0) {
                    pageData.showDatas[num].year = pageData.showDatas[num].year - 1
                    pageData.showDatas[num].month = 11
                } else {
                    pageData.showDatas[num].month = pageData.showMonth - 1;
                }
                pageData.nowIndex = currentIndex;
                pageData.indexCalc = currentIndex;
                _this.goLastMonth(num);
            }
        },
        /////////////////////////////////////////
        // 跳转到今天
        goToday: function (e, showIndex) {
            curMonth = NowMonth;
            curYear = NowYear;
            curDay = NowDay;

            refreshPageData(NowYear, NowMonth - 1, 0, 0);
            refreshPageData(NowYear, NowMonth, NowDay - 1, 1);
            refreshPageData(NowYear, NowMonth + 1, 0, 2);
            if (NowMonth - 1 < 1) {
                pageData.showDatas = [{ year: NowYear - 1, month: 12 }, { year: NowYear, month: 1 }, { year: NowYear, month: 2 }];
            } else if (NowMonth + 1 > 12) {
                pageData.showDatas = [{ year: NowYear, month: 11 }, { year: NowYear, month: 12 }, { year: NowYear + 1, month: 1 }];
            } else {
                pageData.showDatas = [{ year: NowYear, month: NowMonth - 1 }, { year: NowYear, month: NowMonth }, { year: NowYear, month: NowMonth + 1 }];
            }

            if (pageData.nowIndex != 1) {
                swiperChange = false;
            }
            pageData.showMonth = NowMonth; //当前展示的月
            pageData.showYear = NowYear; //当前展示的月
            let firstDayWeek = new Date(NowYear, NowMonth, 1).getDay()
            setCurDetailIndex(firstDayWeek + NowDay - 1, 1);
            // setCurDetailIndex(NowDay,1);
            pageData.nowIndex = 1;
            pageData.indexCalc = 1;
            this.setData(pageData);
        },
        // 跳转上一月
        goLastMonth: function (showIndex) {
            // console.log(e)
            let curDateNow = new Date();
            let curMonthNow = curDateNow.getMonth();
            let curYearNow = curDateNow.getFullYear();

            if (0 == curMonth) {
                curMonth = 11;
                --curYear
            }
            else {
                --curMonth;
            }

            if (curYearNow == pageData.showDatas[showIndex].year && curMonthNow == pageData.showDatas[showIndex].month) {
                refreshPageData(pageData.showDatas[showIndex].year, pageData.showDatas[showIndex].month, curDateNow.getDate() - 1, showIndex);
            } else {
                refreshPageData(pageData.showDatas[showIndex].year, pageData.showDatas[showIndex].month, 0, showIndex);
            }
            // 当前月1号所在的是星期几
            let firstDayWeek = new Date(pageData.showDatas[pageData.nowIndex].year, pageData.showDatas[pageData.nowIndex].month, 1).getDay()
            if (pageData.showDatas[pageData.nowIndex].year == NowYear && pageData.showDatas[pageData.nowIndex].month == NowMonth) { //显示月等于当月
                console.log(firstDayWeek)
                setCurDetailIndex(firstDayWeek + NowDay - 1, pageData.nowIndex);
            } else { //显示页不等于当月
                // setCurDetailIndex(firstDayWeek, pageData.nowIndex);
                setCurDetailIndex(firstDayWeek + pageData.chooseOtherDay - 1, pageData.nowIndex);
                pageData.chooseOtherDay = 1;
            }

            this.setData(pageData);
        },
        // 跳转下一月
        goNextMonth: function (showIndex) {
            let curDateNow = new Date();
            let curMonthNow = curDateNow.getMonth();
            let curYearNow = curDateNow.getFullYear();

            if (11 == curMonth) {
                curMonth = 0;
                ++curYear
            }
            else {
                ++curMonth;
            }

            if (curYearNow == pageData.showDatas[showIndex].year && curMonthNow == pageData.showDatas[showIndex].month) {
                curDay = curDateNow.getDate()
                refreshPageData(pageData.showDatas[showIndex].year, pageData.showDatas[showIndex].month, curDay - 1, showIndex);
            } else {
                curDay = 1;
                refreshPageData(pageData.showDatas[showIndex].year, pageData.showDatas[showIndex].month, curDay - 1, showIndex);
            }
            // 当前月1号所在的是星期几
            let firstDayWeek = new Date(pageData.showDatas[pageData.nowIndex].year, pageData.showDatas[pageData.nowIndex].month, 1).getDay()
            if (pageData.showDatas[pageData.nowIndex].year == NowYear && pageData.showDatas[pageData.nowIndex].month == NowMonth) {
                setCurDetailIndex(firstDayWeek + NowDay - 1, pageData.nowIndex);
            } else {
                // setCurDetailIndex(firstDayWeek, pageData.nowIndex);
                setCurDetailIndex(firstDayWeek + pageData.chooseOtherDay-1, pageData.nowIndex);
                pageData.chooseOtherDay = 1;
            }
            this.setData(pageData);
        },
        // 点击具体的某一天
        selectDay: function (e) {
            let _this = this;
            console.log(e.currentTarget.dataset.month)
            console.log(pageData.showMonth)
            // let firstDayWeek = new Date(NowYear, NowMonth, 1).getDay()
            // setCurDetailIndex(firstDayWeek + NowDay - 1, 1);
            if (e.currentTarget.dataset.month==pageData.showMonth){
                setCurDetailIndex(e.currentTarget.dataset.dayIndex, pageData.nowIndex);

                pageData.date[pageData.nowIndex] = pageData.date[pageData.nowIndex].substring(0, pageData.date[pageData.nowIndex].length - 2);
                if (e.currentTarget.dataset.date > 9) {
                    pageData.date[pageData.nowIndex] += e.currentTarget.dataset.date;
                } else {
                    pageData.date[pageData.nowIndex] += '0' + e.currentTarget.dataset.date;
                }
                
                this.setData({
                    detailData: pageData.detailData,
                    date: pageData.date,
                })
            } else if (e.currentTarget.dataset.month - pageData.showMonth == 1 || e.currentTarget.dataset.month - pageData.showMonth == -11 ){
                console.log("下一个月");
                pageData.chooseOtherDay = e.currentTarget.dataset.date;
                pageData.nowIndex += 1;
                if (pageData.nowIndex > 2){
                    pageData.nowIndex = 0;
                }
                this.setData({
                    nowIndex: pageData.nowIndex
                })
            } else if (e.currentTarget.dataset.month - pageData.showMonth == -1 || e.currentTarget.dataset.month - pageData.showMonth == 11) {
                console.log("上一个月")
                pageData.chooseOtherDay = e.currentTarget.dataset.date;
                pageData.nowIndex -= 1;
                if (pageData.nowIndex < 0) {
                    pageData.nowIndex = 2;
                }
                this.setData({
                    nowIndex: pageData.nowIndex
                })
            }
            
        },
        // 跳转到某一天
        bindDateChange: function (e) {
            var arr = e.detail.value.split("-");
            curYear = +arr[0];
            curMonth = arr[1] - 1;
            curDay = Number(arr[2]);
            // refreshPageData(curYear, curMonth, curDay-1);
            // this.setData(pageData);
            console.log(curYear)
            console.log(curMonth)
            console.log(curDay)
            refreshPageData(curYear, curMonth - 1, 0, 0);
            refreshPageData(curYear, curMonth, curDay - 1, 1);
            refreshPageData(curYear, curMonth + 1, 0, 2);
            if (curMonth - 1 < 1) {
                pageData.showDatas = [{ year: curYear - 1, month: 12 }, { year: curYear, month: 1 }, { year: curYear, month: 2 }];
            } else if (curMonth + 1 > 12) {
                pageData.showDatas = [{ year: curYear, month: 11 }, { year: curYear, month: 12 }, { year: curYear + 1, month: 1 }];
            } else {
                pageData.showDatas = [{ year: curYear, month: curMonth - 1 }, { year: curYear, month: curMonth }, { year: curYear, month: curMonth + 1 }];
            }
            pageData.showMonth = curMonth; //当前展示的月
            setCurDetailIndex(curDay, 1);
            pageData.nowIndex = 1;

            swiperChange = false;
            this.setData(pageData);
        },
        // 判断该月有哪些日期是有日程的
        findMonthSchedule: function(){
            for (let i = 0; i < pageData.arrDays[pageData.nowIndex].length; i++) {
                let date = new Date(pageData.showYear, pageData.arrDays[pageData.nowIndex][i].month, pageData.arrDays[pageData.nowIndex][i].date);
                let arrsNum = 0; //今日的日程总数
                // // 今日日程
                for (let i = 0; i < app.scheduleData.length; i++) {
                    let dateB = new Date(app.scheduleData[i].beginDate.year, app.scheduleData[i].beginDate.month - 1, app.scheduleData[i].beginDate.day);
                    let dateE = new Date(app.scheduleData[i].endDate.year, app.scheduleData[i].endDate.month - 1, app.scheduleData[i].endDate.day);
                    if (date.getTime() - dateB.getTime() >= 0 && date.getTime() - dateE.getTime() <= 0) {
                        arrsNum++;
                    }
                }
                // // 他人推送
                for (let i = 0; i < app.otherScheduleData.length; i++) {
                    let dateB = new Date(app.otherScheduleData[i].beginDate.year, app.otherScheduleData[i].beginDate.month - 1, app.otherScheduleData[i].beginDate.day);
                    let dateE = new Date(app.otherScheduleData[i].endDate.year, app.otherScheduleData[i].endDate.month - 1, app.otherScheduleData[i].endDate.day);
                    if (date.getTime() - dateB.getTime() >= 0 && date.getTime() - dateE.getTime() <= 0) {
                        arrsNum++;
                    }
                }
                if (arrsNum > 0) {
                    pageData.arrDays[pageData.nowIndex][i].showschedule = true;
                } else {
                    pageData.arrDays[pageData.nowIndex][i].showschedule = false;
                }
            }
            this.setData({
                arrDays: pageData.arrDays
            })
        }
    }
})
