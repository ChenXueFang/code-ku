window.onload = function () {
	//1.获取id
	function getId(id){
	    return  document.getElementById(id);
	}
	//2.获取类名
	function getClass(cls){
	    //找到所有的标签
	    var elem = document.all?document.all:document.getElementsByTagName("*");
	    //新建数组
	    var arr = [];
	    //遍历找到所有标签数组
	    for(var i=0; i<elem.length;i++){
	        //判断标签数组所有的元素的类名与传进来的参数cls是否相等
	        if(elem[i].className==cls){
	            //把具有这个类的元素放进arr数组
	            arr.push(elem[i]);
	        }
	    }
	    //把找到的数组传出去
	    return arr;
	}
    //3.获取标签名
    function getEle(ele){
	    return  document.getElementsByTagName(ele);
	}
    
// -------------------------------------------- 
    // 旅游攻略往上滑动的字
    var imgBig = document.getElementsByClassName('tu1');//大图
    var huaHeiBig = document.getElementsByClassName('hua_hei');//大黑色块
    var imgSmall = document.getElementsByClassName('li');//小图
    var huaHeiSmall = document.getElementsByClassName('hua_xiao');//小黑色块
    // 左边大图-------------
    for(let h = 0;h<imgBig.length;h++){
		imgBig[h].index = h;
		imgBig[h].onmousemove = function(){
			for(let j = 0;j<huaHeiBig.length;j++){
				huaHeiBig[j].style.top = '298px';
			}
			huaHeiBig[h].style.top = '273px';
			
		}
		imgBig[h].onmouseout = function(){
			huaHeiBig[h].style.top = '298px';
			
		}
	}
    //右边小图---------------
	for(let e = 0;e<imgSmall.length;e++){
		imgSmall[e].index = e;
		imgSmall[e].onmousemove = function(){
			for(let r = 0;r<huaHeiSmall.length;r++){
				huaHeiSmall[r].style.top = '138px';
			}
			huaHeiSmall[e].style.top = '86px';
			
		}
		imgSmall[e].onmouseout = function(){
			huaHeiSmall[e].style.top = '138px';
			
		}
	}
    
    // 旅游攻略tab切换============
    var strategyTitle = document.getElementsByClassName('strategy_ul')[0];//标题的外壳
    var strategyLis = strategyTitle.getElementsByTagName("li");//指定的标题
    var strategyBox = document.getElementsByClassName('strategy_box')[0];//特惠产品块
    var strategyDivs = strategyBox.getElementsByTagName('b');//指定的产品块
    //2循环遍历,遍历所有的li,绑定点击事件 
    console.log(strategyDivs);
	for(var i=0; i<strategyLis.length; i++){
		strategyLis[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<strategyLis.length; j++){
				//4.this指向discountLis[i]
 				if(this == strategyLis[j]){
 					strategyLis[j].className = "strategy_seleted";
 					strategyDivs[j].className = "strategy_show";
 				}else{
 					strategyLis[j].className = "";
 					strategyDivs[j].className = "";
 				}
			}	
		}	
	}    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}